﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace 日本將棋
{
    abstract class Chess
    {

        public bool camp;

   

        public Chess(bool camp)
        {
            this.camp = camp;
        }
        


        
        public abstract List <ChessBoard.Coordinate> MoveAvailable(ChessBoard chessBoard,int row,int col);
    
        public void SetCamp(bool camp) { this.camp = camp; }


        public abstract Chess DeepCopy();
   

        
    }
}
