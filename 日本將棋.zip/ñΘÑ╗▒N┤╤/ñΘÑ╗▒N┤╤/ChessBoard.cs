﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 日本將棋
{
    class ChessBoard
    {
        public struct Coordinate
        {
            public int row, col;
            public Coordinate(int row,int col)
            {
                this.row = row;
                this.col = col;
                
            }

            public static bool operator ==(Coordinate a,Coordinate b)
            {
                if (a.row == b.row && a.col == b.col) return true;
                else return false;
            }
            public static bool operator !=(Coordinate a, Coordinate b)
            {
                if (!(a.row == b.row && a.col == b.col)) return true;
                else return false;
            }
        }  

        private Chess[,] data = new Chess[10, 10];


        public ChessBoard()
        {
           
        }
        
   
        

        public void AddChess(Chess chess,int row,int col)   //完成
        {
            if(data[row,col]==null)
            {
                data[row, col] = chess;
            }
        }
        
        public Chess GetChess(int row,int col)    
        {
            return data[row, col];
        }

        public bool[,] AttackAvailable(bool camp)    //完成  尚未測試
        {
            bool[,] attackavailable = new bool[10, 10];

            for(int i=1;i<=9;i++)
                for (int j = 1; j <= 9; j++) attackavailable[i,j] = false;
            

            for (int row = 1; row <= 9; row++)
            {
                for (int col = 1; col <= 9; col++)
                {
                    if (data[row, col].camp == camp)
                    {
                        foreach(Coordinate x in data[row, col].MoveAvailable(this,row,col))
                        {
                            attackavailable[x.row, x.col] = true;
                        }
                    }
                }
            }


            return attackavailable;
        }
       

        public Coordinate Get王將Coordinate(bool camp)   //完成  測試通過
        {
            for(int row=1;row<=9;row++)
            {
                for(int col=1;col<=9;col++)
                {
                    if (data[row,col]!=null && data[row,col].GetType() == typeof(王將))
                    {
                        if (data[row, col].camp == camp)
                        {
                            Coordinate coordinate = new Coordinate(row, col);
                            return coordinate;
                        }
                    }
                }
            }


            return new Coordinate(0, 0);
        }
        
        public bool 王將WillDie(bool camp)
        {

            return true;
        }

        public void Remove(int row,int col)
        {
            data[row, col] = null;
        }


        public ChessBoard DeepCopy()
        {
            ChessBoard chessBoard = new ChessBoard();
            for (int row = 1; row <= 9; row++)
            {
                for (int col = 1; col <= 9; col++)
                {
                    if(data[row,col]!=null)
                    chessBoard.data[row, col] = data[row, col].DeepCopy();
                }
            }
            return chessBoard;

        }

    }
}
