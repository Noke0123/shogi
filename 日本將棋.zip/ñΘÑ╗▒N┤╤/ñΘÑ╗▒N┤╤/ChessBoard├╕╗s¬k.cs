﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 日本將棋
{
    class ChessBoard繪製法
    {
        private int latticeLength;

        private Point CoordinateToPoint(ChessBoard.Coordinate coordinate)
        {
            Point point = new Point((coordinate.col - 1) * latticeLength, (coordinate.row - 1) * latticeLength);
            return point;
        }


    }
}
