﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 日本將棋
{
    /*
     * 
     * for(int row=1;row<=9;row++)
            {
                for(int col=1;col<=9;col++)
                {

                }
            }
     * 
     */


    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ChessBoard chessBoard = new ChessBoard();
            ChessBoard chessBoard2 = new ChessBoard();
            Chess temp = new 王將(true); 
            Chess temp2 = new 王將(false);
            Chess ttt = new 飛車(true);
            chessBoard.AddChess(temp, 3,3);
            chessBoard.AddChess(temp2, 1, 3);
            chessBoard2 = chessBoard.DeepCopy();
            //  chessBoard.GetCoordinate(temp2,label1);
            //  if (ttt == temp) label1.Text = "相同";
            //else label1.Text = "不相同";
            chessBoard.Remove(1, 3);
            label1.Text = chessBoard2.Get王將Coordinate(false).row.ToString() +" "+ chessBoard2.Get王將Coordinate(false).col.ToString();



        }
    }
}
