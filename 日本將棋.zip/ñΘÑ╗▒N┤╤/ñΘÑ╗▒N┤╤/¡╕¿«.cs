﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 日本將棋
{
    class 飛車:Chess
    {
        public 飛車(bool camp):base(camp)
        {

        }
        public override List<ChessBoard.Coordinate> MoveAvailable(ChessBoard chessBoard, int row, int col)
        {
            List<ChessBoard.Coordinate> moveAvailable = new List<ChessBoard.Coordinate>();

            for (int i = row - 1; i <= row + 1; i++)
            {
                for (int j = col - 1; j <= col + 1; j++)
                {
                    bool[,] anemyAttackAvailable = chessBoard.AttackAvailable(!camp);
                    if (chessBoard.GetChess(i, j).camp != this.camp)
                    {
                        ChessBoard.Coordinate coordinate = new ChessBoard.Coordinate(i, j);
                        moveAvailable.Add(coordinate);
                    }

                }
            }



            return moveAvailable;
        }

        public override Chess DeepCopy()
        {
            return new 飛車(camp);
        }

    }
}
