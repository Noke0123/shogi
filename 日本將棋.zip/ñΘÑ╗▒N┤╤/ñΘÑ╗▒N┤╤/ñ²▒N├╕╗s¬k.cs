﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 日本將棋
{
    class 王將繪製法 : 棋子的繪製法
    {
        public 王將繪製法()
        {

        }
        public override void Draw(int x, int y, Form1 form1)
        {
            //setImage();
            base.Draw(x, y, form1);
        }

    }
}
