﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 日本將棋
{
    abstract class 棋子的繪製法
    {
        protected PictureBox pictureBox = new PictureBox();

        public 棋子的繪製法()
        {
            setSize(new Size(30,30));
        }

        public virtual void Draw(int x, int y, Form1 form1)
        {
            pictureBox.Location = new Point(x, y);
            pictureBox.Visible = true;
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            form1.Controls.Add(pictureBox);
        }
        public void setSize(Size size)
        {
            pictureBox.Size = size;
        }
        public void setImage(Image image)
        {
            pictureBox.Image = image;
        }
    }
}
